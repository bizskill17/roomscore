<?php
/**
 * Plugin Name: BizSkill Plugin Client SDK Demo
 * Description: Reusable licence and automatic-update client for BizSkill commercial WordPress plugins.
 * Version: 0.1.0
 * Author: BizSkill
 * Text Domain: bizskill-plugin-client
 */

if (!defined('ABSPATH')) exit;

define('BSPC_SDK_VERSION', '0.1.0');
define('BSPC_SDK_DIR', plugin_dir_path(__FILE__));

require_once BSPC_SDK_DIR . 'src/class-bspc-client.php';

/*
 * Demonstration registration only.
 * In a production plugin, bundle src/class-bspc-client.php and call BSPC_Client::register()
 * from that plugin's main file with its own product details.
 */
BSPC_Client::register([
    'product_name'    => 'BizSkill Client SDK Demo',
    'product_slug'    => 'bizskill-client-sdk-demo',
    'plugin_file'     => __FILE__,
    'plugin_basename' => plugin_basename(__FILE__),
    'version'         => BSPC_SDK_VERSION,
    'server_url'      => 'https://plugins.bizskill.in',
]);
