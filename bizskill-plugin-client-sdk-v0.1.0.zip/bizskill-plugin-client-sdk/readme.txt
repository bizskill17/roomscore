=== BizSkill Plugin Client SDK Demo ===
Contributors: bizskill
Requires at least: 6.2
Requires PHP: 8.0
Stable tag: 0.1.0

Reusable client library for licence activation and automatic updates from the BizSkill Plugin Manager Server.

== Production Usage ==
The installable demo plugin proves the workflow. For commercial plugins, bundle src/class-bspc-client.php inside each plugin and register the product from that plugin's main file. See INTEGRATION-EXAMPLE.php.

== Features ==
* One-time licence activation.
* Installation UUID and server-issued activation token.
* WordPress native update notice and Update Now workflow.
* Plugin details modal support.
* Update-check caching.
* Licence activation/deactivation screen.
* No GitHub token on customer websites.

== Important ==
Change server_url from https://plugins.bizskill.in if your update server uses another domain.
