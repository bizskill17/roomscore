<?php
if (!defined('ABSPATH')) exit;

final class BSPC_Client {
    private static array $products = [];
    private array $config;
    private string $option_key;

    public static function register(array $config): self {
        $required = ['product_name','product_slug','plugin_file','plugin_basename','version','server_url'];
        foreach ($required as $field) {
            if (empty($config[$field])) throw new InvalidArgumentException('Missing BizSkill client configuration: ' . $field);
        }
        $client = new self($config);
        self::$products[$client->config['product_slug']] = $client;
        $client->hooks();
        return $client;
    }

    private function __construct(array $config) {
        $this->config = [
            'product_name' => sanitize_text_field($config['product_name']),
            'product_slug' => sanitize_key($config['product_slug']),
            'plugin_file' => $config['plugin_file'],
            'plugin_basename' => $config['plugin_basename'],
            'version' => sanitize_text_field($config['version']),
            'server_url' => untrailingslashit(esc_url_raw($config['server_url'])),
            'menu_parent' => $config['menu_parent'] ?? 'options-general.php',
            'settings_capability' => $config['settings_capability'] ?? 'manage_options',
        ];
        $this->option_key = 'bspc_' . $this->config['product_slug'];
    }

    private function hooks(): void {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_post_bspc_activate_' . $this->config['product_slug'], [$this, 'activate_action']);
        add_action('admin_post_bspc_deactivate_' . $this->config['product_slug'], [$this, 'deactivate_action']);
        add_filter('pre_set_site_transient_update_plugins', [$this, 'inject_update']);
        add_filter('plugins_api', [$this, 'plugin_information'], 20, 3);
        add_filter('plugin_action_links_' . $this->config['plugin_basename'], [$this, 'action_links']);
        add_action('admin_notices', [$this, 'admin_notice']);
    }

    private function state(): array {
        $state = get_option($this->option_key, []);
        if (!is_array($state)) $state = [];
        if (empty($state['instance_id'])) {
            $state['instance_id'] = wp_generate_uuid4();
            update_option($this->option_key, $state, false);
        }
        return $state;
    }

    private function save(array $state): void {
        update_option($this->option_key, $state, false);
    }

    private function endpoint(string $path): string {
        return $this->config['server_url'] . '/wp-json/bizskill-plugins/v1/' . ltrim($path, '/');
    }

    private function request(string $path, array $payload): array {
        $response = wp_remote_post($this->endpoint($path), [
            'timeout' => 20,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'user-agent' => 'BizSkill-Plugin-Client/' . BSPC_SDK_VERSION . '; ' . home_url('/'),
        ]);
        if (is_wp_error($response)) return ['success'=>false,'message'=>$response->get_error_message()];
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body)) return ['success'=>false,'message'=>'Invalid response from licence server.'];
        return $body;
    }

    private function base_payload(array $state): array {
        return [
            'product_slug' => $this->config['product_slug'],
            'license_key' => $state['license_key'] ?? '',
            'activation_id' => $state['activation_id'] ?? '',
            'activation_token' => $state['activation_token'] ?? '',
            'instance_id' => $state['instance_id'] ?? '',
            'site_url' => home_url('/'),
            'plugin_version' => $this->config['version'],
            'installed_version' => $this->config['version'],
            'wordpress_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
        ];
    }

    public function admin_menu(): void {
        add_submenu_page(
            $this->config['menu_parent'],
            $this->config['product_name'] . ' Licence',
            $this->config['product_name'] . ' Licence',
            $this->config['settings_capability'],
            'bspc-' . $this->config['product_slug'],
            [$this, 'settings_page']
        );
    }

    public function settings_page(): void {
        if (!current_user_can($this->config['settings_capability'])) return;
        $state = $this->state();
        $active = !empty($state['activation_id']) && !empty($state['activation_token']);
        echo '<div class="wrap"><h1>' . esc_html($this->config['product_name']) . ' Licence</h1>';
        if (isset($_GET['bspc_message'])) echo '<div class="notice notice-success"><p>'.esc_html(wp_unslash($_GET['bspc_message'])).'</p></div>';
        if (isset($_GET['bspc_error'])) echo '<div class="notice notice-error"><p>'.esc_html(wp_unslash($_GET['bspc_error'])).'</p></div>';
        echo '<table class="widefat striped" style="max-width:760px"><tbody>';
        echo '<tr><th style="width:220px">Product</th><td>'.esc_html($this->config['product_name']).'</td></tr>';
        echo '<tr><th>Installed version</th><td>'.esc_html($this->config['version']).'</td></tr>';
        echo '<tr><th>Licence status</th><td><strong style="color:'.($active?'#16803d':'#b42318').'">'.($active?'Active':'Not active').'</strong></td></tr>';
        if (!empty($state['expires_at'])) echo '<tr><th>Expires</th><td>'.esc_html($state['expires_at']).'</td></tr>';
        echo '</tbody></table>';

        if (!$active) {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:20px;max-width:760px;background:#fff;padding:20px">';
            wp_nonce_field('bspc_activate_' . $this->config['product_slug']);
            echo '<input type="hidden" name="action" value="bspc_activate_'.esc_attr($this->config['product_slug']).'">';
            echo '<label><strong>Licence Key</strong><br><input name="license_key" class="regular-text" required autocomplete="off"></label><p><button class="button button-primary">Activate Licence</button></p></form>';
        } else {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:20px">';
            wp_nonce_field('bspc_deactivate_' . $this->config['product_slug']);
            echo '<input type="hidden" name="action" value="bspc_deactivate_'.esc_attr($this->config['product_slug']).'"><button class="button">Deactivate Licence on This Website</button></form>';
        }
        echo '</div>';
    }

    public function activate_action(): void {
        if (!current_user_can($this->config['settings_capability'])) wp_die('Unauthorised');
        check_admin_referer('bspc_activate_' . $this->config['product_slug']);
        $state = $this->state();
        $state['license_key'] = sanitize_text_field(wp_unslash($_POST['license_key'] ?? ''));
        $result = $this->request('activate', $this->base_payload($state));
        $url = admin_url('admin.php?page=bspc-' . $this->config['product_slug']);
        if (!empty($result['success'])) {
            $state['activation_id'] = sanitize_text_field($result['activation_id'] ?? '');
            $state['activation_token'] = sanitize_text_field($result['activation_token'] ?? '');
            $state['expires_at'] = sanitize_text_field($result['expires_at'] ?? '');
            $state['last_error'] = '';
            $this->save($state);
            delete_site_transient('update_plugins');
            wp_safe_redirect(add_query_arg('bspc_message','Licence activated.',$url)); exit;
        }
        $state['last_error'] = sanitize_text_field($result['message'] ?? 'Activation failed.');
        $this->save($state);
        wp_safe_redirect(add_query_arg('bspc_error',$state['last_error'],$url)); exit;
    }

    public function deactivate_action(): void {
        if (!current_user_can($this->config['settings_capability'])) wp_die('Unauthorised');
        check_admin_referer('bspc_deactivate_' . $this->config['product_slug']);
        $state = $this->state();
        $result = $this->request('deactivate', $this->base_payload($state));
        $url = admin_url('admin.php?page=bspc-' . $this->config['product_slug']);
        if (!empty($result['success'])) {
            $instance = $state['instance_id'];
            $state = ['instance_id'=>$instance];
            $this->save($state);
            delete_site_transient('update_plugins');
            wp_safe_redirect(add_query_arg('bspc_message','Licence deactivated.',$url)); exit;
        }
        wp_safe_redirect(add_query_arg('bspc_error',sanitize_text_field($result['message'] ?? 'Deactivation failed.'),$url)); exit;
    }

    private function update_data(bool $force = false): array {
        $state = $this->state();
        if (empty($state['activation_id']) || empty($state['activation_token']) || empty($state['license_key'])) return [];
        $cache_key = 'bspc_update_' . md5($this->config['product_slug'] . home_url('/'));
        if (!$force) {
            $cached = get_site_transient($cache_key);
            if (is_array($cached)) return $cached;
        }
        $result = $this->request('check-update', $this->base_payload($state));
        if (empty($result['success'])) {
            $state['last_error'] = sanitize_text_field($result['message'] ?? 'Update check failed.');
            $this->save($state);
            set_site_transient($cache_key, [], HOUR_IN_SECONDS);
            return [];
        }
        $state['last_error'] = '';
        $this->save($state);
        set_site_transient($cache_key, $result, 6 * HOUR_IN_SECONDS);
        return $result;
    }

    public function inject_update($transient) {
        if (!is_object($transient)) $transient = new stdClass();
        $data = $this->update_data();
        if (empty($data['update_available']) || empty($data['version']) || empty($data['package'])) return $transient;
        if (version_compare($data['version'], $this->config['version'], '<=')) return $transient;
        $item = (object)[
            'id' => $this->config['product_slug'],
            'slug' => $this->config['product_slug'],
            'plugin' => $this->config['plugin_basename'],
            'new_version' => sanitize_text_field($data['version']),
            'url' => $this->config['server_url'],
            'package' => esc_url_raw($data['package']),
            'requires' => sanitize_text_field($data['requires'] ?? ''),
            'tested' => sanitize_text_field($data['tested'] ?? ''),
            'requires_php' => sanitize_text_field($data['requires_php'] ?? ''),
        ];
        $transient->response[$this->config['plugin_basename']] = $item;
        return $transient;
    }

    public function plugin_information($result, string $action, object $args) {
        if ($action !== 'plugin_information' || ($args->slug ?? '') !== $this->config['product_slug']) return $result;
        $data = $this->update_data();
        if (!$data) return $result;
        return (object)[
            'name' => $this->config['product_name'],
            'slug' => $this->config['product_slug'],
            'version' => sanitize_text_field($data['version'] ?? $this->config['version']),
            'author' => '<a href="https://bizskill.in">BizSkill</a>',
            'homepage' => 'https://bizskill.in',
            'requires' => sanitize_text_field($data['requires'] ?? ''),
            'tested' => sanitize_text_field($data['tested'] ?? ''),
            'requires_php' => sanitize_text_field($data['requires_php'] ?? ''),
            'download_link' => esc_url_raw($data['package'] ?? ''),
            'sections' => is_array($data['sections'] ?? null) ? $data['sections'] : [],
        ];
    }

    public function action_links(array $links): array {
        $url = admin_url('admin.php?page=bspc-' . $this->config['product_slug']);
        array_unshift($links, '<a href="'.esc_url($url).'">Licence</a>');
        return $links;
    }

    public function admin_notice(): void {
        if (!current_user_can($this->config['settings_capability'])) return;
        $state = $this->state();
        if (!empty($state['activation_id'])) return;
        $url = admin_url('admin.php?page=bspc-' . $this->config['product_slug']);
        echo '<div class="notice notice-warning"><p><strong>'.esc_html($this->config['product_name']).':</strong> Activate your licence to receive automatic updates. <a href="'.esc_url($url).'">Activate licence</a></p></div>';
    }
}
