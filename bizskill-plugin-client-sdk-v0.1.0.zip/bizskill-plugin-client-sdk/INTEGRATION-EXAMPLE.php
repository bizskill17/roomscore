<?php
/**
 * Copy the src directory into your commercial plugin, then place this code in
 * that plugin's main file after defining its version constant.
 */

require_once __DIR__ . '/bizskill-client/src/class-bspc-client.php';

BSPC_Client::register([
    'product_name'    => 'RoomScore',
    'product_slug'    => 'roomscore',
    'plugin_file'     => __FILE__,
    'plugin_basename' => plugin_basename(__FILE__),
    'version'         => HRIM_VERSION,
    'server_url'      => 'https://plugins.bizskill.in',
    // Optional: put the licence page under your plugin menu instead.
    // 'menu_parent'  => 'hotel-inspection-dashboard',
]);
